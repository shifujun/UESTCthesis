jobname=thesis
./clean.sh
rm $jobname.pdf
pdflatex -shell-escape ./$jobname.tex
makeindex -s $jobname.ist -t $jobname.glg -o $jobname.gls $jobname.glo
bibtex ./$jobname.aux
bibtex ./publications.aux
pdflatex -shell-escape ./$jobname.tex
pdflatex -shell-escape ./$jobname.tex
./clean.sh
clear
echo ****************************************************************************
echo ��ʽ����ǰӦ�÷���https://github.com/shifujun/UESTCthesis���ģ���Ƿ��и��£�
echo ****************************************************************************
