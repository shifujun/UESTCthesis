jobname=uestcthesis
./clean.sh
rm $jobname.pdf
pdflatex ./$jobname.dtx
makeindex -s gglo.ist -o %jobname%.gls %jobname%.glo
pdflatex ./$jobname.dtx
latex .\%jobname%.ins